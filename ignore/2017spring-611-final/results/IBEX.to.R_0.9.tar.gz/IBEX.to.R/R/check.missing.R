check.missing <-
function (x, string, name) {
  missing.values <- which(!(x %in% string))
  missing.values <- x[missing.values]
  
  if (length(missing.values)==length(x)&length(x)>0) 
    stop ("None of the ", name," (", paste0(missing.values, collapse=", "), ") is found in the data")
  if (length(missing.values)>0) 
    message ("The following ", name, " are not found in the data: ",
             paste0(missing.values, collapse=", "))  
  return(length(missing.values))
  
}
