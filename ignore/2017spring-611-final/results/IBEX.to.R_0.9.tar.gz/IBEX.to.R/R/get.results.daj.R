get.results.daj <-
function (d, elem.number=NULL,
                              del.col=c(2,4),
                              col.names=c("question", "answer", "is.correct",
                                          "rt", "sentence"),
                              list=NULL, sprt = FALSE, 
                              sep.quest = FALSE, save.to="")
{
 
if(!is.character(d)&!is.data.frame(d)) stop ("d must be either character or data.frame")
  
  

# Now it depends on what the mode is. If not sprt, the life is eaaasy.
    
    # --------- 1. Speeded acceptability mode ----------------------
    if (!sprt){
      
      if (is.character(d)) d <- read.ibex(d, col.names)
      res.raw <- d[d[3]=="DashedAcceptabilityJudgment",]     
      if (NROW(res.raw)==0) stop ("Subsetting for DashedAcceptabiltyJudgment controller failed.\n",
                                  "Check the data")
      
      if (!missing(sep.quest)) message ("Sep.quest parameter is not used if sprt=FALSE(default)\n")
      
      # check whether the data.frame has supposed number of columns
      if (NCOL(d)<11) stop ("Dashed Acceptability Judgment controller in acceptability mode\n",
                           "creates 11 columns, but the number of columns in the data.frame\n",
                           "is less than 11.\n",
                           "Check whether the data was read into R completely")
      
      #------------ read the data ------------------------
      
      # read even lines, which contain info about questions.
      # we read all the columns, so almost all the information is already extracted
      res <- res.raw[(seq(2, NROW(res.raw), by=2)),  ]
      if (NROW(res)==0) stop ("Subsetting for questions data failed")
      rownames(res) <- NULL
      
      # if the mode is sprt (and we think that we're now in Speeded acceptability), 
      # then some of the cells in column 12 will be empty. check it.
      if (length(which(res[12]==""))>0) stop ("The mode of the data may be sprt, ",
                                    "while you set the mode to Acceptability Judgment. ",
                                    "Check the data. See IBEX manual for more details about the modes.\n")
    
      # ensuring correct types of data in the columns
      check.numeric(res[[11]], col.names[4])  
      res[[11]] <- as.numeric(as.character(res[[11]])) # rt should be numeric
      
      # read odd lines with the info about Sentences. Here we read only the
      # last column, which has number 8
      res.Sentences <- res.raw[(seq(1, NROW(res.raw), by=2)), 8 ]
      if (NROW(res.Sentences)==0) stop ("Subsetting for sentence data failed")
      #-----------------------------------------------------
      
      
      # add column with question info after immediately after all the other info, 
      # but before empty columns (if they exist)
      res[,12] <- res.Sentences
      droplevels(res)
      
      #Check whether Is.correct column can be deleted
      if (NROW(unique(res[10]))==1) if (res[1,10]=="NULL") del.col <- c(del.col,10)
            
      # now pass this data set to the default procedure, so
      # column naming, deletion and other stuff could happen
      res <- get.results(res, controller="DashedAcceptabilityJudgment",
                         elem.number, del.col, col.names, list, save.to)
      
      # return data and exit the function
      return (res)
    }
    
    #---------------------------------------------------
    #---------------------------------------------------
    # Now, if the mode is "SPRT", we have troubles...
    
    
    # ---------------- 2. SPRT mode -----------------------
    
    #If the user didn't specify the columns, set default names
    if (missing(col.names)) col.names <- c("region",
                                           "word",
                                           "rt",
                                           "line.break",
                                           "sentence")

    if (is.character(d)) d <- read.ibex(d, col.names)
    res.raw <- d[d[3]=="DashedAcceptabilityJudgment",]     
    if (NROW(res.raw)==0) stop ("Subsetting for DashedAcceptabiltyJudgment controller failed.\n",
                                "Check the data")

    # check whether the data.frame has supposed number of columns
    if (NCOL(d)<12) stop ("Dashed Acceptability Judgment controller in sprt mode\n",
                          "creates 12 columns, but the number of columns in the data.frame\n",
                          "is less than 12.\n",
                          "Check whether the data was read into R completely")
   
    if (NROW(unique(d[12]))==1 & is.na(d[1,12])) 
      stop ("The mode of the data may be Acceptabilty Judgment ",
            "while you set the mode to sprt. ",
            "Check the data. See IBEX manual for more details about the modes.\n")
    
    # ---------------- Get Sentences data --------------------
    # In the rows containing Sentences the 12th column is not empty. 
    # We are subsetting sentences basing on this.
    res.Sentences <- res.raw[res.raw[,12]!="",  ]
    if (NROW(res.Sentences)==0) stop ("Subsetting for sentence data failed")
    rownames(res.Sentences) <- NULL 
    res.Sentences <- droplevels(res.Sentences)

    # ensuring correct types of data in the columns
    res.Sentences[8] <- factor(res.Sentences[[8]]) # region is a factor
    check.numeric(res.Sentences[[10]], col.names[3])  
    res.Sentences[[10]] <- as.numeric(as.character(res.Sentences[[10]])) # rt should be numeric

    # If New line? contains only FALSE, it can be deleted
    if (NROW(unique(res.Sentences[11]))==1) if (res.Sentences[1,11]== "False") del.col <- c(del.col,11)

    # ������� � � ��� �������� ������� ���������!
    
    # How many data.frames should we return?
    
    # ------------- 2.1. if asked to return a single data.frame -------------
    if (!sep.quest){
      
      # ----------- Get Questions data ------------------------------------
      # Subset for Questions. Get only the relevant columns, i.e 8-11
      res.Questions <- res.raw[res.raw[,12]=="", c(8:11)]
      if (NROW (res.Questions)==0) stop ("Failed to get questions data")
      rownames(res.Questions) <- NULL
      
      
      # Nooow. Each sentence adds n rows to the results, where n is the number
      # of words in the sentence. However, each question adds only one line.
      # If we try to merge those two data.frames (res.Sentences and res.Questions),
      # an error will be thrown in.
      # So what we do is repeating question info on each line of Sentence results.
      # To do this, we need to count the number of words in each sentence. 
      # LET'S DO THIS!!!
      
      # ---------------- count the number of words in sentences -------
      # Get the numbers of rows with Questions
      res.Questions.rows <- which(res.raw[,12]=="")
      # Create temp vector of the same length as res.Question.rows,
      # but starting with 0 and without the last value
      temp <- c(0, res.Questions.rows)
      temp <- temp[-length(temp)]
      
      # Now, we count the distance between two Question lines, and correct it by 1.
      # this gives us the number of words in a sentence.
      N.words <- res.Questions.rows - (temp+1)
      
      res.Questions.rep <- NULL
      
      #--------------- make Questions matrix ---------------------
      # In the loop we repeat each line of Questions n times, where n is the
      # number of words in the corresponding sentence
      for (i in 1:NROW(res.Questions)){
        
        res.Questions.rep <- c(res.Questions.rep, 
                               rep(as.vector(as.matrix(res.Questions[i,])),
                                   times=N.words[i])) 
        
      }
      
      # Add Questions info to the result data.frame
      res <- cbind(res.Sentences, matrix(res.Questions.rep, 
                                         nrow=NROW(res.Sentences), 
                                         ncol=4, byrow=TRUE,
                                         dimnames=list(NULL, c("question",
                                                               "answer",
                                                               "is.correct",
                                                               "answer.rt"))))
      # set col.names for further callof get.results
      col.names <- c(col.names, c("question",
                                  "answer",
                                  "is.correct",
                                  "answer.rt"))
      
      res <- droplevels(res)
      
      #-------------- Set column names for the resulting data.frame ---------------------
      # if the user specified less than 4 column names, ensure that
      # column names related to Questions will be given to correct columns.
#       n.cols <- 5
#       
#       if (length (col.names)<n.cols) {col.names <- c(col.names, 
#                                                 paste0("Col",seq_len(n.cols-length(col.names))))}
#       
         
     
      # ensuring correct types of data in the columns
     
     check.numeric(res[[16]], col.names[9])  
     res[[16]] <- as.numeric(as.character(res[[16]])) # rt should be numeric
      
      # if Is.correct column (which is 15-th) contains only NULLs, it can be deleted
      if (NROW((unique(res[15]))==1)) if (res[1,15]=="NULL") del.col <- c(del.col,15)
      
      # call the default function
      res <- get.results(res, controller="DashedAcceptabilityJudgment",
                         elem.number, del.col, col.names, list, save.to)
      cat ("1 data.frame returned with Sentences and Questions pooled\n\n")
    }
    
    
    # ------------------- 2.2. if asked for two separate data.frames -------------
    else{
      
      # Tell the user that two data.frames are indeed returned
      cat("2 separate data.frames for Sentences and Questions returned as list\n\n")
      cat("Info about deleted columns in \n 1) Sentences data.frame;\n",
          "2) Questions data.frame:\n\n")
      
      #--------------- Create Sentences data.frame ------------------
      # Determine which columns to delete in the first (i.e. Sentences) data.frame
      del.col.low <- which(del.col <= 12)
      del.col.low <- del.col[del.col.low]
      
      # Call the default function for the sentences
      res.Sentences <- get.results(res.Sentences, 
                                   controller="DashedAcceptabilityJudgment",
                                   elem.number, del.col.low, 
                                   col.names, list,
                                   save.to=paste(save.to,"_Sentences.csv",sep=""))
      
      
      #------------ prepare Questions data ---------------
      # Questions are the raws which DO have an empty string in the 12th column
      res.Questions <- res.raw[res.raw[,12]=="", ]
      # 12th column is gonna to be empty
      res.Questions[12] <- NULL
      rownames(res.Questions) <- NULL
      res.Questions <- droplevels(res.Questions)
      colnames(res.Questions)[8:11] <- c("question",
                                        "answer",
                                        "is.correct",
                                        "answer.rt") 
      
      # Set the names of the columns for the get.results call
      col.names.quest <- c("question",
                           "answer",
                           "is.correct",
                           "answer.rt")
      # ensuring correct types of data in the columns
      
      check.numeric(res.Questions[[11]], col.names[4])  
      res.Questions[[11]] <- as.numeric(as.character(res.Questions[[11]])) # rt should be numeric
      
      # if Is.correct column (which is 10th in this case) contains only NULLs, it can be deleted
      if (NROW((unique(res.Questions[10]))==1)) if (res.Questions[1, 10]=="NULL") {del.col <- c(del.col,15)}
      
      # Determine which columns to delete in the second(i.e. Questions) data.frame
      # By default the columns are deleted from the whole data.frame.
      # So if they are separate, the indices of the columns in Questions will be
      # shifted by 5 (number of columns in Sentences). Account for this and
      # subtract 5.
      
    
      del.col.high <- (del.col[del.col>12])-5
      del.col.high <- c(del.col[del.col<=7], del.col.high)
      if (length(del.col.high)==0) {
        del.col.high <- NULL
      }
      
      # --------------Create Questions data.frame --------------------------
      res.Questions <- get.results(res.Questions, 
                                   controller="DashedAcceptabilityJudgment",
                                   elem.number, del.col.high,
                                   col.names.quest, list,
                                   save.to=paste(save.to,"_Questions.csv",sep=""))
      
      
      # return the list with two data.frames
      res <- list(res.Sentences, res.Questions)
    }
    
    
    return (res)
    
}
