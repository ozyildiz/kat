numbers.only <-
function (x){
  res <- suppressWarnings(is.na(sapply((x), as.numeric)))
  if (length(which(res)) > 0) return (which(res))
  else return (NULL)
}
