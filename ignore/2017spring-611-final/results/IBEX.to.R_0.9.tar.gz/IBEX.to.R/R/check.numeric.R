check.numeric <-
function(x, col.name) {
  NaN.values <- which.not.numbers (x) 
  if (!is.null(NaN.values)) {
  message ("\nApart from numeric values ", col.name," column contains also the following values: \"",
             paste0(NaN.values, collapse="\", \""), "\". They are coerced to NAs")
  }
}
